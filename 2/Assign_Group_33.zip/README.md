# Group Members
1. Rahul Mandal (20CS30039)
2. Sailada Vishnu Vardhan (20CS10051)




# Libraries used for Part 1
1. numpy
2. pandas
3. matplotlib
4. sklearn



# Libraries used for Part 2
1. math
2. pandas
3. numpy
4. sklearn
5. matplotlib 




# How to run codes

### Install the dependencies given above
### Run code using : "python q1.py" and "python q2.py" 


